//
//  main.cpp
//  Project1
//
//  Created by Gautam Anand on 4/8/23.
//
#include <iostream>
#include <string>
#include <random>
#include <utility>
#include <cstdlib>
#include <cctype>
#include "Rabbit.h"
#include "globals.h"
#include "Arena.h"
#include "Game.h"
#include "globals.h"
#include "Player.h"
using namespace std;

int main()
{
      // Create a game
      // Use this instead to create a mini-game:
    Game g(10, 12, 40);
////
      // Play the game
    g.play();


}


